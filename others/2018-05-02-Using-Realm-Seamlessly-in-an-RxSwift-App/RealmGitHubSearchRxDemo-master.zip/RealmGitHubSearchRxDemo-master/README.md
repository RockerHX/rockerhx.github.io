# RealmGitHubSearchRxDemo
The demo app for RxRealm's post on realm.io

All the fits in a single view controller class to showcase the use of realm + rx for demonstration purposes. You should probably use a proper architecture in your own apps.

* [RealmSwift](https://github.com/realm/realm-cocoa)
* [RxRealm](https://github.com/RxSwiftCommunity/RxRealm)

## Demo app

To run the demo app install the dependancies via CocoaPods by running `pod install` in the app directory or via your preferred dependency management method.